import numpy as np
import pymatgen as pm
import itertools
from supertb import CoverTree
from copy import deepcopy
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from scipy.spatial import KDTree
import networkx as nx
import os
from time import clock


def close_vertices(n):

    nx, ny, nz = n
    return  np.array([[ix, iy, iz] for ix in range(nx+1)+range(-nx,0) \
                                   for iy in range(ny+1)+range(-ny,0) \
                                   for iz in range(nz+1)+range(-nz,0)],dtype=int)

def cartesian_vertices():

    cv = np.zeros((7,3))
    cv[1:3,0] = [-1,1]
    cv[3:5,1] = [-1,1]
    cv[5:7,2] = [-1,1]
    return cv

class Lattice(pm.Lattice):
    """
    A lattice object.  Essentially a matrix with conversion matrices.
    This class is based on the Lattice class from Pymatgen, and extends
    the latter by adding methods associated with periodic distances and
    images.      
    """
    def __init__(self,*args,**kwargs):
        """
        Creates a lattice from any sequence of 9 numbers. Note that the sequence
        is assumed to be read one row at a time. Each row represents one
        lattice vector.

        Args:
            matrix: Sequence of numbers in any form. Examples of acceptable
                input.
                i) An actual numpy array.
                ii) [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
                iii) [1, 0, 0 , 0, 1, 0, 0, 0, 1]
                iv) (1, 0, 0, 0, 1, 0, 0, 0, 1)
                Each row should correspond to a lattice vector.
                E.g., [[10, 0, 0], [20, 10, 0], [0, 0, 30]] specifies a lattice
                with lattice vectors [10, 0, 0], [20, 10, 0] and [0, 0, 30].
        """

        if isinstance(args[0],pm.Lattice):
            super(Lattice,self).__init__(args[0].matrix)
        else:
            super(Lattice,self).__init__(*args,**kwargs)

        self._cart_vertices = np.array([x for x in cartesian_vertices()],dtype=np.int)
        self._cart_vectors = np.array([np.dot(self.matrix,x) for x in self._cart_vertices])


    def cdist(self, p):
        """
        Replicates the coordinate given as argument in neighboring cartesian cell 
        and identifies the replica associated with the smallest distance to the origin.

        Returns the indices of the selected replica and the computed distance.
        """
        
        dist = np.linalg.norm(p-self._cart_vectors, axis=-1)
        argmin = dist.argmin()

        return argmin, dist[argmin]

    def periodic_data(self, v, frac_coords=False):
        
        if frac_coords:
            vec = self.get_cartesian_coords(np.reshape(v,(3)))
        else:
            vec = np.reshape(v,(3))
            
        argmin = 1
        period = np.zeros(3)
        image = np.zeros(3,dtype=np.int)
        
        while argmin != 0:
            argmin, dist = self.cdist(vec)
            vertex = self._cart_vertices[argmin]
            dv = self._cart_vectors[argmin]
            image += vertex
            period += dv
            vec -= dv

        return dist, image, period

    def periodic_vector(self, v):
        
        argmin = 1
        period = np.zeros(3)
        
        while argmin != 0:
            argmin, dist = self.cdist(vec)
            dv = self._cart_vectors[argmin]
            period += dv
            vec -= dv

        return period

    def periodic_distance(self, v):

        argmin = 1
        while argmin != 0:
            argmin, dist = self.cdist(vec)
            dv = self._cart_vectors[argmin]
            vec -= dv

        return dist

    def image(self, v, frac_coords=False):
	"""
	Computes the indices of the lattice unit-cell to which
        the vector belongs.

        Args:
            v: (1D array) 
                Vector coordinates.
            frac_coords: (Boolean)
                Whether the vector coordinates are fractional or 
                cartesian. Defaults is False.
	"""

        if frac_coords:
            vec = np.reshape(v,(3))
        else:
            vec = self.get_fractional_coords(np.reshape(v,(3)))

        return np.floor(vec).astype(int)

    def distance(self, v):
	"""
	Computes the length of the vector given as argument.

        Args:
            v: (1D array) 
                Vector coordinates.
	"""

	return np.linalg.norm(vec,axis=-1)

    @classmethod
    def from_pymatgen(cls,pm_lattice):
	"""
        Creates a Lattice object from a pymatgen lattice object 	

        Args:
            pm_lattice: pymatgen lattice object
	"""

	return cls(pm_lattice.matrix)

    @classmethod
    def from_parameters(cls,*args,**kwargs):
        """
        Creates a Lattice using unit cell lengths and angles (in degrees).

        Args:
            a (float): *a* lattice parameter.
            b (float): *b* lattice parameter.
            c (float): *c* lattice parameter.
            alpha (float): *alpha* angle in degrees.
            beta (float): *beta* angle in degrees.
            gamma (float): *gamma* angle in degrees.

        Returns:
            Lattice with the specified lattice parameters.
        """
    
	return cls.from_pymatgen(pm.Lattice.from_parameters(*args,**kwargs))

    @classmethod
    def from_lengths_and_angles(cls,*args,**kwargs):
        """
        Creates a Lattice using unit cell lengths and angles (in degrees).

        Args:
            abc (3x1 array): Lattice parameters, e.g. (4, 4, 5).
            ang (3x1 array): Lattice angles in degrees, e.g., (90,90,120).

        Returns:
            A Lattice with the specified lattice parameters.
        """       
 
	return cls.from_pymatgen(pm.Lattice.from_lengths_and_angles(*args,**kwargs))

    @classmethod
    def cubic(cls,*args,**kwargs):
        
	return cls.from_pymatgen(pm.Lattice.cubic(*args,**kwargs))

    @classmethod
    def tetragonal(cls,*args,**kwargs):
        
	return cls.from_pymatgen(pm.Lattice.tetragonal(*args,**kwargs))

    @classmethod
    def orthorhombic(cls,*args,**kwargs):
        
	return cls.from_pymatgen(pm.Lattice.orthorhombic(*args,**kwargs))

    @classmethod
    def monoclinic(cls,*args,**kwargs):
        
	return cls.from_pymatgen(pm.Lattice.monoclinic(*args,**kwargs))

    @classmethod
    def hexagonal(cls,*args,**kwargs):
        
	return cls.from_pymatgen(pm.Lattice.hexagonal(*args,**kwargs))

    @classmethod
    def rhombohedral(cls,*args,**kwargs):
        
	return cls.from_pymatgen(pm.Lattice.rhombohedral(*args,**kwargs))

class Structure(pm.Structure):
    """
    A Structure object.  
    This class is based on the Structure class from Pymatgen, and extends
    the latter by adding methods associated with periodic distances and
    images.      
    """
    
    def __init__(self, lattice, species, coords, validate_proximity=False,
                 coords_are_cartesian=False, site_properties=None):
        """
        Create a periodic structure.

        Args:
            lattice: The lattice, either as a pymatgen.core.lattice.Lattice or
                simply as any 2D array. Each row should correspond to a lattice
                vector. E.g., [[10,0,0], [20,10,0], [0,0,30]] specifies a
                lattice with lattice vectors [10,0,0], [20,10,0] and [0,0,30].
            species: List of species on each site. Can take in flexible input,
                including:

                i.  A sequence of element / specie specified either as string
                    symbols, e.g. ["Li", "Fe2+", "P", ...] or atomic numbers,
                    e.g., (3, 56, ...) or actual Element or Specie objects.

                ii. List of dict of elements/species and occupancies, e.g.,
                    [{"Fe" : 0.5, "Mn":0.5}, ...]. This allows the setup of
                    disordered structures.
            coords: list of fractional coordinates of each species.
            validate_proximity (bool): Whether to check if there are sites
                that are less than 0.01 Ang apart. Defaults to False.
            coords_are_cartesian (bool): Set to True if you are providing
                coordinates in cartesian coordinates. Defaults to False.
            site_properties (dict): Properties associated with the sites as a
                dict of sequences, e.g., {"magmom":[5,5,5,5]}. The sequences
                have to be the same length as the atomic species and
                fractional_coords. Defaults to None for no properties.
        """
        if not isinstance(lattice, Lattice):
	    pm.Structure.__init__(self, Lattice(lattice), species, coords, \
                validate_proximity=validate_proximity, to_unit_cell=True,\
                coords_are_cartesian=coords_are_cartesian, \
                site_properties=site_properties)
        else: 
	    pm.Structure.__init__(self,lattice, species, coords, \
                validate_proximity=validate_proximity, to_unit_cell=True,\
                coords_are_cartesian=coords_are_cartesian, \
                site_properties=site_properties)


    def make_supercell(self, scaling_matrix, to_unit_cell=False):
        """
        Create a supercell.

        Args:
            scaling_matrix: A scaling matrix for transforming the lattice
                vectors. Has to be all integers. Several options are possible:

                a. A full 3x3 scaling matrix defining the linear combination
                   the old lattice vectors. E.g., [[2,1,0],[0,3,0],[0,0,
                   1]] generates a new structure with lattice vectors a' =
                   2a + b, b' = 3b, c' = c where a, b, and c are the lattice
                   vectors of the original structure.
                b. An sequence of three scaling factors. E.g., [2, 1, 1]
                   specifies that the supercell should have dimensions 2a x b x
                   c.
                c. A number, which simply scales all lattice vectors by the
                   same factor.
            to_unit_cell: Whether or not to fall back sites into the unit cell
        """
        s = self*scaling_matrix
        if to_unit_cell:
            for isite, site in enumerate(s):
                s[isite] = site.to_unit_cell
        return Structure.from_pymatgen(s)

    def _make_ordered_supercell(self, scaling):
       
        nx,ny,nz = scaling
        lattice = Lattice((self.lattice.matrix.T*np.array(scaling)).T)
        struct = Structure(lattice,[],[])
    
        for ix in range(nx):
            for iy in range(ny):
                for iz in range(nz):
                    for site in self.sites:
                        coords = site.coords + np.dot([ix,iy,iz],self.lattice.matrix)
                        struct.append(site.specie,coords,coords_are_cartesian=True)

     	return struct

    @classmethod
    def from_pymatgen(cls, pmg_struct):
	"""
        Creates a Lattice object from a pymatgen lattice object 	

        Args:
            pm_lattice: pymatgen lattice object
	"""

	return cls(pmg_struct.lattice, pmg_struct.species, pmg_struct.frac_coords)

    def query_pairs(self, rcut, newtree=True, distance=None):
        """
        Find all pairs of atomic sites whose distance is smaller or equal
        to rcut.


        Args:
            rcut: (float)
                Cuttof radius
            newtree: (Boolean)
                Wether to force or not to build a new kd-tree for quick  
                nearest-neighbor lookup. Default=False
            distance: (callable object) 
                a two-argument callable object returning a float.
                Given two points return the distance between them.
                Default=None (meaning that the lattice periodic distance is used).
        """

        if newtree or not hasattr(self,'ktree'):

            if distance == None:
                tree_distance = lambda x, y: self.lattice.periodic_distance(y-x, frac_coords=False)
            else:
                tree_distance = distance

            if len(self.cart_coords) < 1:
                raise IndexError('Structure.frac_coords is empty!')
	    self.ktree = CoverTree(self.cart_coords,tree_distance)

        return self.ktree.query_pairs(rcut)

    def show_vesta(self,label=None):
        
        if label == None:
            # Create a tmp directory
            current_dir = os.getcwd()
            os.system("mkdir .tmp_vesta")
            os.chdir(current_dir+"/.tmp_vesta")
            afile = 'tmp.xsf'
        else:
            # Create a directory
            current_dir = os.getcwd()
            os.system("mkdir "+label+"_vesta")
            os.chdir(current_dir+"/"+label+"_vesta")
            afile=label+'.xsf'
            
        # Create an xsf file 
        fh = open(afile, 'w')
        fh.write('PRIMVEC \n')
        for v in self.lattice_vectors():
            fh.write(' %.14f %.14f %.14f\n' % tuple(v))

        fh.write('PRIMCOORD \n')
        coords=np.dot(np.array(self.frac_coords), self.lattice.matrix)
        fh.write('%d %d\n' %tuple((len(self.frac_coords),1)))
        for pos, Z in zip(coords, self.species):
            fh.write('%d %.14f %.14f %.14f\n' % tuple((Z.Z,pos[0],pos[1],pos[2])))
        fh.close()
    
        # Use Vesta to visualize the xsf file
        os.system("/Applications/VESTA/VESTA.app/Contents/MacOS/VESTA "+afile)
    
        # Delete the tmp directory
        os.chdir(current_dir)
        if label==None:
            os.system("rm -r ./.tmp_vesta")



class StructureGraph(nx.MultiDiGraph):
    """
    A StructureGraph object designed to perform tight-binding calculations.  
    This class is based on the MultiDiGraph class from Networkx, and extends
    the latter by adding methods to automatically create a Graph from a
    Structure, with appropriate nodes and edges attribute.  
    """
 
    @property
    def lattice(self):
        return self.graph['lattice']

    def empty_graph(self):

        G = nx.MultiDiGraph()

        for node in self.nodes_iter():
            G.add_node(node)

        for i, j, k in self.edges_iter(keys=True):
            G.add_edge(i,j)

        return G    

    def nodes_attributes(self, *args):
        nodes = []
        attributes = []
        nodes = []
        for node, data in self.nodes_iter(data=True):
            nodes.append((node,) + tuple([data[key] for key in args if key in data]))

        return  zip(*nodes)

    def color_edges(self, omax=8):

        if not hasattr(self,'clock_loops') or \
           not hasattr(self,'anti_clock_loops'):
            self.simple_2D_loops(omax=omax)
  
        for edge in self.edges_iter(keys=True):

            color = [0,0]
            for loop in self.clock_loops:
                if edge in loop:
                    color[0] = len(loop)

            for loop in self.anti_clock_loops:
                if edge in loop:
                    color[1] = -len(loop)

            i, j ,k = edge
            self[i][j][k]['colors'] = color

    def color_nodes(self, clockwise=True, omax=8):

        if clockwise and not hasattr(self,'clock_loops'):
            self.simple_2D_loops(omax=omax)
        elif not clockwise and not hasattr(self,'anti_clock_loops'):
            self.simple_2D_loops(omax=omax)
  
        for node in self.nodes_iter(data=False):

            color = []
            if clockwise:
                for loop in self.clock_loops:
                    for i,j,k in loop:
                        if i == node:
                            color.append(len(loop))
                            break
            else:
                for loop in self.anti_clock_loops:
                    for i, j, k in loop:
                        if i == node:
                            color.append(-len(loop))
                            break

            self.node[node]['colors'] = color

    def simple_2D_loops(self, omax=8):

        self.clock_loops = []
        self.anti_clock_loops = []
        for i,j,k in self.edges_iter(keys=True):

            edge = (i,j,k)

            found = False
            for loop in self.clock_loops:
                if edge in loop:
                    found = True
                    break
            if not found:
                loop = self.clockwise_loop(edge, omax=omax)
                self.clock_loops.append(loop)
             
            found = False
            for loop in self.anti_clock_loops:
                if edge in loop:
                    found = True
                    break
            if not found:
                loop = self.clockwise_loop(edge, omax=omax, anti=True)
                self.anti_clock_loops.append(loop)

    def clockwise_loop(self, edge, omax=8, anti=False):

        start_node, inode, iedge = edge
        vec = deepcopy(self[start_node][inode][iedge]['vector'])
        nvec = vec/np.linalg.norm(vec)
        vectot = deepcopy(vec)

        #print "----------------------------------------------------------------------"
        #print "Start node & edge :"
        #print start_node, inode, iedge, nvec
        #print "----------------------------------------------------------------------"

        loop = [edge]
        for order in range(omax):
            best_dot_product = 1.
            found = False
            for knode in self[inode]:
                for kedge in self[inode][knode]:
                    vec_trial = self[inode][knode][kedge]['vector']
                    nvec_trial = vec_trial/np.linalg.norm(vec_trial)

                    #print "---test edge: ", inode, knode, kedge, nvec_trial  

                    cross_product = np.cross(nvec, nvec_trial)[2]
                    dot_product = np.dot(nvec, nvec_trial)

                    #print "...vector products:  ", cross_product, dot_product

                    if (cross_product < -0.001 and not anti) or \
                       (cross_product > 0.001 and anti):
                        #print "   --> cross product OK!"
                        if dot_product < best_dot_product:
                            #print "   --> best dot product !", dot_product, best_dot_product
                            best_edge = (inode, knode, kedge)
                            best_nvec = nvec_trial
                            best_vec = vec_trial
                            best_node = knode
                            best_dot_product = dot_product
                            found = True

            if found :
                nvec = best_nvec
                inode = best_node
                vectot += best_vec 
                loop.append(best_edge)

                #print "----------------------------------------------------------------------"
                #print "New node & edge :"
                #print best_edge, nvec
                #print "----------------------------------------------------------------------"
        
            if inode == start_node:
                if np.linalg.norm(vectot) < 0.01:
                    break     

        return loop

              
    def increase_graph_order(self,order, colors = False):

        G = deepcopy(self)
        for k in range(order):
            K = G.add_neighbors_to_graph(colors = colors)
            G = deepcopy(K)            

        return G


    def add_neighbors_to_graph(self, colors = False):
        
        G = deepcopy(self)
        for inode in self.nodes():
            ispec = self.node[inode]['species']
            coords = self.node[inode]['coords']

            for jnode in self.successors(inode):
                for jedge in self[inode][jnode]:
                    jm = self[inode][jnode][jedge]['image']
                    jv = self[inode][jnode][jedge]['vector']
                    jp = self[inode][jnode][jedge]['path'] 

                    for knode in self.successors(jnode):
                        for kedge in self[jnode][knode]:

                            if self[jnode][knode][kedge]['order'] > 1:
                                continue

                            km = self[jnode][knode][kedge]['image']
                            kv = self[jnode][knode][kedge]['vector']
                            newv = jv + kv                            

                            accept = True
                            if knode in G[inode]:
                                for ledge in G[inode][knode]:
                                    lv = G[inode][knode][ledge]['vector']
                                    if np.linalg.norm(lv-newv) < 0.01:
                                        accept = False
                                        break
                            if np.linalg.norm(newv) < 0.01:
                                accept = False

                            if accept:
                                newm = jm + km
                                newp = deepcopy(jp)
                                newp.append((jnode,knode,kedge))

                                neworder = len(newp)
                                newspec = self.node[knode]['species']
                                length = np.linalg.norm(newv)

                                G.add_edge(inode, knode, vector=newv, coords=coords, \
                                          length=length, order=neworder, image=newm, \
                                          species=(ispec,newspec), path=newp)

        G.add_path_vectors()
        if colors:
            G.propagate_edge_colors()

        return G

    def add_path_vectors(self):

        for i, j, k, data in self.edges_iter(keys=True, data=True):
            self[i][j][k]['path_vectors'] = []
            for l, m, n in data['path']:
                vector =  self[l][m][n]['vector']
                self[i][j][k]['path_vectors'].append(vector)

    def propagate_edge_colors(self):

        for i, j, k, data in self.edges_iter(keys=True, data=True):
            if 'colors' not in self[i][j][k]:
                path = self[i][j][k]['path'] 

                color = []
                for loop in self.clock_loops:
                    inloop = True
                    for edge in path:
                        if edge not in loop:
                            inloop = False
                            break
                      
                    if inloop:
                        color.append(len(loop))

                for loop in self.anti_clock_loops:
                    inloop = True
                    for edge in path:
                        if edge not in loop:
                            inloop = False
                            break
                      
                    if inloop:
                        color.append(-len(loop))

                self[i][j][k]['colors'] = color


    @classmethod
    def init_from_structure(cls, struct, rcut, inout=False):
        """
        Creates a StructureGraph from a Structure object.

        Args:
            struct: 
                Structure object. The nodes of the created StructureGraph
                are associated with the atomic sites of the structure.  
            rcut: 
                Cutoff-radius used to determine the graph connectivity.
                An edge is associated with each air of atomic coordinates 
                whose distance is smaller than rcut.
        """	

        # WARNING:
        # this method requires the atoms to lie within the unit cell
        # (i.e. only rationalised fractional coords)  

        size = len(struct.sites)
        lat = struct.lattice

        # Creates a temporary array containings all potential external coordinates 
        ortho = np.array([v/np.linalg.norm(v) for v in lat.inv_matrix.T])*rcut
        delta = np.array([np.dot(ortho[i],lat.inv_matrix)[i] for i in range(3)])
        nsc = np.ceil(delta).astype(np.int)
        vertices = close_vertices(nsc)[1:]
        
        extra_frac_coords = []
        extra_species = []
        extra_sites = []
        for isite, ifrac in enumerate(struct.frac_coords):
            p = ifrac + vertices
            for ix in range(3):
                ptmp = p[np.logical_and(p[:,i]>-delta[i], p[:,i]<1.+delta[i])]   
                p = ptmp
            for frac in p:
                extra_frac_coords.append(frac)
                extra_species.append(struct.species[isite])
                extra_sites.append(isite)
                
            
        # Create kdtree with all the internal coordinates
	kdi = KDTree(struct.cart_coords)

        # Create kdtree with all the external coordinates
        extra_cart_coords = np.dot(np.array(extra_frac_coords),lat.matrix)
        kdo = KDTree(extra_cart_coords)

        # Create graph
        graph = StructureGraph(lattice=lat)

	# Add nodes to graph
	for i in range(size):
	    graph.add_node(i, species=struct.species[i].symbol, coords=struct.cart_coords[i]) 

        # Add internal edges to graph
        for isite, jsite in kdi.query_pairs(rcut):
 
            #print 'Internal edge : ', isite, jsite
            icart = struct.cart_coords[isite]
            jcart = struct.cart_coords[jsite]
            ispec = struct.species[isite].symbol
            jspec = struct.species[jsite].symbol
 
            vec = jcart - icart
            length = np.linalg.norm(vec)
            image = np.zeros(3,dtype=np.int)

            graph.add_edge(isite, jsite, vector=deepcopy(vec), coords=struct.cart_coords[isite], \
                     length=length, order=1, species=(ispec,jspec), image=image)
            graph.add_edge(jsite, isite, vector=-deepcopy(vec), coords=struct.cart_coords[jsite], \
                     length=length, order=1, species=(jspec,ispec), image=image)


        # Add external edges to graph
        for isite, neighbors in enumerate(kdi.query_ball_tree(kdo,rcut)):

            
            #print 'External neighbors : ', isite, neighbors
            icart = struct.cart_coords[isite]
            ispec = struct.species[isite].symbol
            
            for jn in neighbors:
           
                jcart = extra_cart_coords[jn]
                jspec = extra_species[jn].symbol
                jsite = extra_sites[jn]


                vec = jcart - icart
                length = np.linalg.norm(vec)
                image = lat.image(icart+vec)

                graph.add_edge(isite, jsite, vector=vec, coords=struct.cart_coords[isite], \
                         length=length, order=1, species=(ispec,jspec), image=image)
        
        for i, j, k in graph.edges_iter(keys=True):
            graph[i][j][k]['path'] = [(i,j,k)]

        return graph

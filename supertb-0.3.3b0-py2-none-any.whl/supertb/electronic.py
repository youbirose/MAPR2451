"""
This module defines the classes and functions that enables to compute single 
particle hamiltonians and eigenstates from interaction parameters 
(e.g. tight-binding or Slatter-Koster).
"""

import time
import numpy as np
import pickle
from math import exp, log, sin, cos, pi, sqrt, trunc, ceil
import scipy.constants as const
import scipy.linalg as linalg
import scipy.sparse as sparse
import scipy.sparse.linalg as spalg 
import scipy
from scipy.interpolate import splev, splrep

from copy import copy, deepcopy
from supertb import AtomicBasisSet, Eigenset, BlochPhase, Spinor
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
import matplotlib.pyplot as plt
import warnings


class ElectronicStructure(object):
    """
    An object that gathers what is needed to compute an electronic structure
    at the tight-binding level. 

    .. attribute:: graph

       The StructureGraph object use to determine the geometry of the system as well 
       as the connectivity of the tight-binding Hamiltonian.
 
    .. attribute:: lattice

       The lattice defining the periodicity of the system.

    .. attribute:: table

       The AtomicTable listing the numerical atoms present in the system.
       
    .. attribute:: spin

       The Spinor object ruling the dimensionality of the spin manifold

    .. attribute:: basis

       The AtomicBasisSet used to expand the Hamiltonian

    .. attribute:: basis

       A copy of the StructureGraph provided used to store the computed blocks 
       of the Hamiltonian and Overlap matrices 

    .. attribute:: inter

       A dictionary of all the user provided interactions (i.e. the place where 
       all the Slater-Koster parameters are stored). 

    .. attribute:: spacegroup

       The computed spacegroup of the system

    """

    def __init__(self, graph, table, spinpol=False, spinorb=False, spacegroup=None, \
                 symmetry=False, **kwargs):
        """
        Creates an Electronic Structure object.

        Args:
            graph: (StructureGraph object)
                Structure and connectivity of the system under consideration.
            table: (AtomicTable object)     
                Definition of the numerical atoms present in the system.
            spinpol: (Boolean)
                Determines wheter the system is spin polarized or not.
                Default: False.
            spinorb: (Boolean)
                Determines wheter the system is described by means of spinor
                wavefunctions or not, (i.e. does the description account for 
                the spin-orbit coupling).
                Default: False.
            spacegroup: (Spacegroup object)
                Spacegroup of the system. 
                Default: None.
            **kwargs: 
                List of user provided interaction provided as keyword arguments.
        """

        self.graph = graph
        self.lattice = graph.lattice
 	self.table = table
        self.spin = Spinor(spinpol=spinpol,spinorb=spinorb)
        self._bloch = BlochPhase(self.table, dim=self.spin.dim)

        # Create basis set
        idx, spec = self.graph.nodes_attributes('species')
        self.basis = AtomicBasisSet(idx, spec, table) 

        # Electronic structure
        self.egraph = self.graph.empty_graph()

        # Atomic interactions
        self.inter = dict()
        for key in kwargs:
            self.inter[key] = deepcopy(kwargs[key])

        # Symmetries
	if spacegroup != None:
            self.spacegroup = spacegroup

    @property
    def orthogonal(self):
        orthogonal = True
        for key in self.inter:
            if self.inter[key].overlap:
                orthogonal = False
                break
        return orthogonal

    def compute_integrals(self, *args):

        #t0 = time.clock()
        if len(args) == 0:
            args = [key for key in self.inter]

        local_inter = []
        non_local_inter = []
        for arg in args:
            if  hasattr(self.inter[arg],'local_block'):
                local_inter.append(arg)
            if  hasattr(self.inter[arg],'non_local_block'):
                non_local_inter.append(arg)

        for inode in self.graph.nodes_iter():
            for arg in local_inter:
                self.egraph.node[inode][arg] = \
                    self.inter[arg].local_block(inode, self.graph) 

        for edge in  self.graph.edges_iter(keys=True): 
            inode, jnode, jedge = edge
            for arg in non_local_inter:
                self.egraph[inode][jnode][jedge][arg] =  \
                    self.inter[arg].non_local_block(edge, self.graph) 

        #t1 = time.clock()
        #print 'compute_integrals: total time = ', t1-t0, ' (sec)'

    def compute_bloch_phase(self, kpt=[0.,0.,0.]):

        for inode, jnode, jedge, data in  self.graph.edges_iter(keys=True,data=True):
            spec_a, spec_b = data['species']
            vec = data['vector']
            self.egraph[inode][jnode][jedge]['bloch'] =  \
                    self._bloch.non_local_block(spec_a, spec_b, vec, kpt) 

    def compute_S(self, include=[], bloch=False):

        ovlp = np.zeros((self.basis.size, self.basis.size, \
                        self.spin.dim[0], self.spin.dim[1]),dtype=complex)

        if len(include) == 0:
            include = [key for key in self.inter]

        slocs = [el for el in include if (self.inter[el].overlap and \
                   hasattr(self.inter[el],'local_block'))]  

        for inode, data in self.egraph.nodes_iter(data=True):

            mat = deepcopy(data[slocs[0]])
            for arg in slocs[1:]:
                mat += data[arg]

            istart = self.basis.first_basis_on_site(inode)
            istop = self.basis.last_basis_on_site(inode)+1
            ovlp[istart:istop,istart:istop,:,:] += mat
 
        snlocs = [el for el in include if (self.inter[el].overlap and \
                   hasattr(self.inter[el],'non_local_block'))]  
          
        sphase = [el for el in include if (self.inter[el].peierls and \
                   hasattr(self.inter[el],'non_local_block'))]  
  
        for inode, jnode, jedge, data in  self.egraph.edges_iter(keys=True,data=True): 

            mat = deepcopy(data[snlocs[0]])
            for arg in snlocs[1:]:
                mat = mat + data[arg] 
 
            for arg in sphase:
                mat = mat * data[arg] 

            if bloch:
                mat = mat * data['bloch']

            istart = self.basis.first_basis_on_site(inode)
            istop = self.basis.last_basis_on_site(inode)+1
            jstart = self.basis.first_basis_on_site(jnode)
            jstop = self.basis.last_basis_on_site(jnode)+1
            ovlp[istart:istop,jstart:jstop,:,:] += mat

        return ovlp


    def compute_H(self, include=[], bloch=False):

        #t0 = time.clock()
        ham = np.zeros((self.basis.size, self.basis.size, \
                        self.spin.dim[0], self.spin.dim[1]),dtype=complex)

        if len(include) == 0:
            include = [key for key in self.inter]

        hlocs = [el for el in include if (self.inter[el].hamiltonian and \
                   hasattr(self.inter[el],'local_block'))]  

        for inode, data in self.egraph.nodes_iter(data=True):

            mat = deepcopy(data[hlocs[0]])
            for arg in hlocs[1:]:
                mat = mat + data[arg]

            istart = self.basis.first_basis_on_site(inode)
            istop = self.basis.last_basis_on_site(inode)+1
            ham[istart:istop,istart:istop,:,:] += mat
 
 
        hnlocs = [el for el in include if (self.inter[el].hamiltonian and \
                   hasattr(self.inter[el],'non_local_block'))]  
        
        hphase = [el for el in include if (self.inter[el].peierls and \
                   hasattr(self.inter[el],'non_local_block'))]  
  
        for inode, jnode, jedge, data in  self.egraph.edges_iter(keys=True,data=True): 

            mat = deepcopy(data[hnlocs[0]])
            for arg in hnlocs[1:]:
                mat = mat + data[arg] 

            for arg in hphase:
                mat = mat * data[arg] 

            if bloch:
                mat = mat * data['bloch']

            istart = self.basis.first_basis_on_site(inode)
            istop = self.basis.last_basis_on_site(inode)+1
            jstart = self.basis.first_basis_on_site(jnode)
            jstop = self.basis.last_basis_on_site(jnode)+1
            ham[istart:istop,jstart:jstop,:,:] += mat


        #t1 = time.clock()
        #print 'compute_H : total time = ', t1-t0, ' (sec)'

        return ham

    def compute_HS(self, include=[], bloch=False):
        
        ham = self.compute_H(include=include, bloch=bloch)
        ovlp = self.compute_S(include=include, bloch=bloch)
    
        return ham, ovlp

    def solveigh(self, include=[], eigvec=False, bloch=False):

        eigenvecs = []
        eigenvals = []

        #t0 = time.clock()
        if not self.orthogonal:
            H, S = self.compute_HS(include=include, bloch=bloch)  
            for ispin in range(self.spin.nspin):
                Hmat = self.spin.reshape(H,ispin)
                Smat = self.spin.reshape(S,ispin)
            
                if eigvec:
                   eigh_vals, eigh_vecs = linalg.eigh(Hmat, Smat,\
                       lower=False, turbo=True, eigvals_only=False)
                   eigenvals.append(eigh_vals)
                   eigenvecs.append(eigh_vecs.T)
                else:
                   eigh_vals = linalg.eigh(Hmat, Smat,\
                       lower=False, turbo=True, eigvals_only=True)
                   eigenvals.append(eigh_vals)

        else:
            H = self.compute_H(include=include, bloch=bloch)               
            for ispin in range(self.spin.nspin):
                Hmat = self.spin.reshape(H,ispin)

                if eigvec:
                   eigh_vals, eigh_vecs = linalg.eigh(Hmat,\
                       lower=False, turbo=True, eigvals_only=False)
                   eigenvals.append(eigh_vals)
                   eigenvecs.append(eigh_vecs.T)
                else:
                   eigh_vals = linalg.eigh(Hmat,\
                       lower=False, turbo=True, eigvals_only=True)
                   eigenvals.append(eigh_vals)
        #t1 = time.clock()
        #print 'solveigh : total time = ', t1-t0, ' (sec)'

        if eigvec:
            return np.transpose(np.array(eigenvals),(1,0)), \
                   np.transpose(np.array(eigenvecs),(1,0,2))
        else:
            return np.transpose(np.array(eigenvals),(1,0))

    def lines_kpoints(self, kpoints, nkpts, fractional=True):
        
        kpts = np.empty((sum(nkpts)+1,3))

        ptr = 0
	for il in range(len(kpoints)/2):
	    kstart = np.array(kpoints[2*il])
            kstop = np.array(kpoints[2*il+1])
	    step = (kstop-kstart)/nkpts[il]
            kpts[ptr:ptr+nkpts[il],:] = np.array([kstart+ik*step for ik in range(nkpts[il])])
            ptr += nkpts[il]

        kpts[ptr] = np.array(kpoints[-1])

        if fractional: 
           kpts = np.array([np.dot(kpt,self.lattice.reciprocal_lattice.matrix) for kpt in kpts])

        return kpts, np.array([1.]*len(kpts))/len(kpts)


    def irreducible_kpoints(self, mesh=(0,0,0), is_shift=(0,0,0), shift=(0.,0.,0.)):
        
        if not hasattr(self,'spacegroup'):
            mp = []
            for idir in range(3):
                mp.append(np.array([((2.*(ik+1)-mesh[idir]-1)/(2.*mesh[idir]))+shift[idir] for ik in range(mesh[idir])]))
            kx,ky,kz = np.meshgrid(mp[0],mp[1],mp[2])
            kpts = np.array([np.dot(kpt, self.lattice.reciprocal_lattice.matrix) \
                             for kpt in np.vstack((kx.flatten(),ky.flatten(),kz.flatten())).T])
            wkpts = np.array([1 for ik in range(len(kpts))])
        else:
            kptlist = self.spacegroup.get_ir_reciprocal_mesh(mesh=mesh, is_shift=is_shift)
            kpts = np.array([np.dot(kpt[0],self.lattice.reciprocal_lattice.matrix) for kpt in kptlist])
            kcounts = np.array([np.float(kpt[1]) for kpt in kptlist])
            wkpts = kcounts/np.sum(kcounts)
  
        return kpts, wkpts


    def eigenvalues(self, include=[], compute=[], eigvec=False, gamma=False,\
                 kpts=[[0.,0.,0.]], wkpts=[1.], fractional=False):

        if len(compute) > 0:
            self.compute_integrals(*compute)

        if fractional: 
           kpts = np.array([np.dot(kpt,self.lattice.reciprocal_lattice.matrix) for kpt in kpts])
        else:
           kpts = np.array(kpts)

        if not hasattr(include,'__iter__'):
            include = [include]
      
        eigenset = Eigenset(self.lattice, spin=self.spin, kpts=kpts, wkpts=wkpts, fractional=False)

        bloch = not gamma
        for ikpt, kpt in enumerate(kpts): 
 
           
            if not gamma:
                self.compute_bloch_phase(kpt=kpt)
        
            if eigvec:
                eigenvals, eigenvecs = self.solveigh(include=include, eigvec=eigvec, bloch=bloch)
                eigenset.set_kpt_eigenvalues(eigenvals, eigenvecs, ikpt=ikpt) 
            else:
                eigenvals = self.solveigh(include=include, eigvec=eigvec, bloch=bloch)
                eigenset.set_kpt_eigenvalues(eigenvals, ikpt=ikpt) 
       


        return eigenset 


    def eigen_on_grid(self, include=[], compute=[], eigvec=False,\
                      mesh=(0,0,0), is_shift=(0,0,0)):

        kpts, wkpts = self.irreducible_kpoints(mesh=mesh, is_shift=is_shift)
 
        return self.eigenvalues(include=include, compute=compute, eigvec=eigvec, gamma=False,\
                              kpts=kpts, wkpts=wkpts, fractional=False)
         
    def bands_structure(self, include=[], compute=[], eigvec=False,\
                       lines=[], nkpts=[], kpts=[], wkpts=[], fractional=True):

        if kpts != []:
            if fractional: 
               kpts = np.array([np.dot(kpt,self.lattice.reciprocal_lattice.matrix) for kpt in kpts])
            else:
               kpts = np.array(kpts)
        elif lines != []:
            kpts, wkpts = self.lines_kpoints(lines, nkpts, fractional=fractional)

        return self.eigenvalues(include=include, compute=compute, eigvec=eigvec, gamma=False,\
                              kpts=kpts, wkpts=wkpts, fractional=False)

    @property
    def optim_variables(self):

        optim_variables = []
        for key in self.inter:
            optim_variables = optim_variables + self.inter[key].optim_variables

        return optim_variables

    def update_optim_variables(self, **kwargs):

        for key in self.inter:
            self.inter[key].update_optim_variables(**kwargs)



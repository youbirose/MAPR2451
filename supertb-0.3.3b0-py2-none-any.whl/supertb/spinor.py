"""
This module defines basic classes and functions to deal with colinear 
and non-colinear spin on the same footing.... 
"""

import numpy as np

def mpauli(kind):

    if kind == 'x' or kind == 1:
        return np.array([[0.,1.+0.j],[1.+0.j,0.]])
    elif kind == 'y' or kind == 2:
        return np.array([[0.,-1j],[1j,0.]])
    elif kind == 'z' or kind == 3:
        return np.array([[1.,0.],[0.,-1.]])
    elif kind == 'i' or kind == 0:
        return np.array([[1.+0.j,0.],[0.,1.+0.j]])

class Spinor(int):

    def __new__(cls, *args, **kwargs):

        if 'nspin' in kwargs:
            nspin = kwargs['nspin']
        elif len(args) > 0:
            nspin = args[0]
        else:
            nspin = 1

        if 'spinorb' in kwargs:
            spinorb = kwargs['spinorb']
        else:
            spinorb = False

        if 'spinpol' in kwargs:
            spinpol = kwargs['spinpol']
        else:
            spinpol = False

        if 'dim' in kwargs:
            nspin = np.prod(kwargs['dim'])

        if spinorb or nspin == 4:
            spinorb = True
            spinpol = True
            nspin = 1
            dim = [2,2]
            identity = np.reshape([[1.+0.j,0.+0.j],[0.+0.j,1.+0.j]],dim)
            nbasis = 2
            deg = 1

        elif spinpol or nspin == 2:
            spinorb = False
            spinpol = True
            nspin = 2 
            dim = [2,1]
            identity = np.reshape([1.+0.j,1.+0.j],dim) 
            nbasis = 1
            deg = 1

        elif nspin == 1:
            spinorb = False
            spinpol = False
            nspin = 1
            dim = [1,1]
            identity = np.reshape([1.+0.j],dim)                                         
            nbasis = 1
            deg = 2

        spinor = int.__new__(cls, nspin)
        spinor.nspin = nspin
        spinor.dim = dim
        spinor.identity = identity
        spinor.nbasis = nbasis
        spinor.deg = deg
        spinor.spinorb = spinorb
        spinor.spinpol = spinpol

        return spinor

    def reshape(self, spinmat, ispin):

        row_size = spinmat.shape[0]
        col_size = spinmat.shape[1]

        mat = np.zeros((row_size*self.nbasis, col_size*self.nbasis),dtype=complex)
        if self.dim[1] == 2:
            mat[0:row_size,0:col_size] = spinmat[:,:,0,0]
            mat[0:row_size,col_size:2*col_size] = spinmat[:,:,0,1]
            mat[row_size:2*row_size,0:col_size] = spinmat[:,:,1,0]
            mat[row_size:2*row_size,col_size:2*col_size] = spinmat[:,:,1,1]
        elif self.dim[0] == 2:
            mat[:,:] = spinmat[:,:,ispin,0]
        else:
            mat[:,:] = spinmat[:,:,0,0]

        return mat


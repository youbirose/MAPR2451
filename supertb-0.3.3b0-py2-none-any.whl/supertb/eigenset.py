"""
"""

import numpy as np
import pickle
from math import exp, log, sin, cos, pi, sqrt, trunc, ceil
import scipy.constants as const
import scipy.linalg as linalg
import scipy.sparse as sparse
import scipy.sparse.linalg as spalg 
import scipy
from scipy.interpolate import splev, splrep

from copy import copy, deepcopy
from supertb import BlochPhase, Spinor, AtomicBasisSet
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
import matplotlib.pyplot as plt
import warnings

class Eigenset(object):

    def __init__(self, lattice, **kwargs):
 
        self.lattice = lattice

        if 'spin' in kwargs:
            self.spin = kwargs['spin']
        else:
            self.spin = Spinor(**kwargs)

        if 'kpts' in kwargs:
            kpts = kwargs['kpts']
        else:
            kpts = [[0.,0.,0.]]

        if 'fractional' in kwargs:
            fractional = kwargs['fractional']
        else:
            fractional = False

        if fractional:
            self.kpts = np.array([np.dot(kpt,lattice.reciprocal_lattice.matrix) \
                                      for kpt in kpts])
        else:
            self.kpts = kpts

        if 'vertices' in kwargs:
            self.vertices = kwargs['vertices']

        if 'wkpts' in kwargs:
            self.wkpts = kwargs['wkpts']
        else:
            #self.wkpts = [1.]*len(self.kpts)
            self.wkpts = [1./len(self.kpts)]*len(self.kpts)

        self.eigenval = dict() 
        for ikpt in range(len(kpts)):
            self.eigenval[ikpt] = dict()
   
    def set_bands(self, ener):

        self.set_all_eigenvalues(ener)
        self.bands = np.array(ener)         
     
    def set_all_eigenvalues(self, ener):
        
        self.check_kpoint_index(ener.shape[0]-1)
        for ikpt, kener in enumerate(ener):
            self.set_kpt_eigenvalues(kener, ikpt=ikpt)
        
    def set_kpt_eigenvalues(self, ener, ikpt=0):

        self.check_spin_index(ener.shape[1]-1)
        for iband, band in enumerate(ener):
            for ispin, eband in enumerate(band):
                self.create_entry(ikpt, iband, ispin)
                self.eigenval[ikpt][iband][ispin]['E'] = eband

    def set_eigenvalue(self, ener, ikpt=0, iband=0, ispin=0):

        self.check_kpoint_index(ikpt)
        self.create_entry(ikpt=ikpt, iband=iband, ispin=ispin)
        self.eigenval[ikpt][iband][ispin]['E'] = ener

    def eigenvalues_iter(self):

        for ikp in self.eigenval:
            for iband in self.eigenval[ikp]:
                for ispin in self.eigenval[ikp][iband]:
                    if 'E' in self.eigenval[ikp][iband][ispin]:
                        yield ikp, iband, ispin, self.eigenval[ikp][iband][ispin]['E']

    def set_bands_projections(self, projs):
 
        self.set_all_projections(projs)
        self.bands_projections = np.array(projs)

    def set_all_projections(self, projs):

        self.check_kpoint_index(projs.shape[0]-1)
        for ikpt, kprojs in enumerate(projs):
            self.set_kpt_projections(kprojs, ikpt=ikpt)

    def set_kpt_projections(self, projs, ikpt=0):    

        self.check_spin_index(projs.shape[1]-1)
        for iband, band in enumerate(projs):
            for ispin, proj in enumerate(band):
                self.create_entry(ikpt, iband, ispin)
                self.eigenval[ikpt][iband][ispin]['P'] = proj

    def set_projection(self, proj, ikpt=0, iband=0, ispin=0):

        self.check_kpoint_index(ikpt)
        self.create_entry(ikpt=ikpt, iband=iband, ispin=ispin)
        self.eigenval[ikpt][iband][ispin]['P'] = proj

    def projections_iter(self):

        for ikp in self.eigenval:
            for iband in self.eigenval[ikp]:
                for ispin in self.eigenval[ikp][iband]:
                    if 'P' in self.eigenval[ikp][iband][ispin]:
                        yield ikp, iband, ispin, self.eigenval[ikp][iband][ispin]['P']

    def create_entry(self, ikpt=0, iband=0, ispin=0):
        
        if iband not in self.eigenval[ikpt]:
            self.eigenval[ikpt][iband] = dict()
        if ispin not in self.eigenval[ikpt][iband]:
            self.eigenval[ikpt][iband][ispin] = dict()

    def check_kpoint_index(self, ikpt):

        if ikpt >= len(self.kpts):
            error_msg = "Error in Eigenset object : index of k-point is out of range, " + ikpt
            raise IndexError(error_msg)

    def check_spin_index(self, ispin):

        if ispin >= self.spin.nspin:
            error_msg = "Error in Eigenset object : spin dimension is out of range, " + ispin
            raise IndexError(error_msg)

    def kpt_index(self, kpt, fractional=True, ktol=1.e-14):

        if not fractional:
            kpt = np.dot(kpt,lattice.reciprocal_lattice.inv_matrix)
 
        idx = None
        for ikpt, old_kpt in enumerate(self.kpts) :
            if np.linalg.norm(old_kpt-kpt) < ktol:
                idx = ikpt
                break
    
        return idx 

    def shift_bands_indexes(self, shift):

        spin = deepcopy(self.spin)
        eigenset = Eigenset(self.lattice, spin=spin, kpts=self.kpts, wkpts=self.wkpts)  

        for ikpt, iband, ispin, eig in self.eigenvalues_iter():
            eigenset.set_eigenvalue(eig, ikpt=ikpt, iband=iband+shift, ispin=ispin)         
        
        for ikpt, iband, ispin, proj in self.projections_iter():
            eigenset.set_projection(proj, ikpt=ikpt, iband=iband+shift, ispin=ispin)         

        return eigenset
    
    def add_non_colinear_spin(self):

        if self.spin.nspin == 1:
            spin_shift = [0,1]
        elif self.spin.nspin == 2:
            spin_shift = [0]

        spin = Spinor(spinorb=True)
        eigenset = Eigenset(self.lattice, spin, kpts=self.kpts, wkpts=self.wkpts)

        for ikpt, iband, ispin, eig in self.eigenvalues_iter():
            for ishift in spin_shift:
                eigenset.set_eigenval(eig, ikpt=ikpt, iband=2*iband+ispin+ishift, ispin=0)         
        
        fac = 1./len(spin_shift)
        for ikpt, iband, ispin, proj in self.projections_iter():
            for ishift in spin_shift:
                new_proj = proj*fac
                eigenset.set_projection(new_proj, ikpt=ikpt, iband=2*iband+ispin+ishift, ispin=0)         

        return eigenset
  
    @property
    def eigenvalues_matrix(self):

        if not hasattr(self,'bands'):
            ee = []
            for ikp in self.eigenval:
                ek = []
                for iband in self.eigenval[ikp]:
                    espin = []
                    for ispin in self.eigenval[ikp][iband]:
                        espin.append(self.eigenval[ikp][iband][ispin]['E'])
                    ek.append(espin)
                ee.append(ek)
            ee = np.array(ee)        
            
            return ee 
        else:
            return self.bands

    @property
    def projections_matrix(self):

        if not hasattr(self,'bands'):
            ee = []
            for ikp in self.eigenval:
                ek = []
                for iband in self.eigenval[ikp]:
                    espin = []
                    for ispin in self.eigenval[ikp][iband]:
                        espin.append(self.eigenval[ikp][iband][ispin]['P'])
                    ek.append(espin)
                ee.append(ek)
            ee = np.array(ee)        
            
            return ee 
        else:
            return self.bands


    def select(self, klist=[], wklist=[], ksub=[], emin=None, emax=None, \
                         imin=0, imax=10, ktol=1.e-06, bshift=0):


        if len(klist) >= 1:
            ikps = []
            for jkp, newkpt in enumerate(klist):
                for ikp, oldkpt in enumerate(self.kpts):
                   ndiff = np.linalg.norm(np.array(newkpt)-oldkpt)
                   if ndiff <= ktol:
                       ikps.append(ikp)
                       if len(wklist) >= 1:
                           wkpts[ikp] = wklist[jkp]
                       break
        elif len(ksub) >= 1:
            ikps = ksub
            wkpts = self.wkpts
        else:
            ikps = range(len(self.kpts))
            wkpts = self.wkpts

        selected_eigvals = []
        selected_ikps = []
        selected_bands = []

        if emin != None and emax != None:
            for ikp in ikps:
                for iband in self.eigenval[ikp]:
                    for ispin in self.eigenval[ikp][iband]:
                        ee = self.eigenval[ikp][iband][ispin]['E']
                        if (emin <= ee and ee <= emax):
                            if ikp not in selected_ikps:
                                selected_ikps.append(ikp)
                            jkp = selected_ikps.index(ikp)
                            selected_bands.append((jkp, iband, ispin))
                            selected_eigvals.append(ee)

        else:
            for jkp, ikp in enumerate(ikps):
                selected_ikps.append(ikp)
                for iband in range(imin,imax+1):
                    for ispin in self.eigenval[ikp][iband]:
                        ee = self.eigenval[ikp][iband][ispin]['E']
                        selected_bands.append((jkp,iband,ispin))
                        selected_eigvals.append(ee)

        selected_kpts = np.array(self.kpts)[selected_ikps]
        selected_wkpts = np.array(wkpts)[selected_ikps]
        eigenset = Eigenset(self.lattice, spin=self.spin, \
                            kpts=selected_kpts, wkpts=selected_wkpts, \
                            fractional=False)

        for idx, band in enumerate(selected_bands):
            ikp, iband, ispin = band
            eigenset.set_eigenvalue(selected_eigvals[idx], ikpt=ikp, \
                                    iband=iband, ispin=ispin)

        return eigenset.shift_bands_indexes(bshift)



    def plot_bands(self, emin=None, emax=None, xmin=None, xmax=None, \
             kshift=0, spincolors=[], eshift=0., xscale=True, \
             klabels=[], vertices=[], labelint=False, ylabel=None, \
             delta_bands=[], bands=[], yfactor=1., **kwargs):

        # K-points coordinates
        nkpts = self.kpts.shape[0]
        if xscale:
            xaxis = [0.]
            for ik in range(1,nkpts):
                d = np.linalg.norm((self.kpts[ik]-self.kpts[ik-1])*self.wkpts[ik])
                xaxis.append(d+xaxis[ik-1])
            xaxis = np.array(xaxis)-xaxis[kshift]
        else:
            xaxis = np.array(range(nkpts))


        # Plot eigenvalues
        ener = self.eigenvalues_matrix
        nk, nb, ns = ener.shape
        if len(bands) != 0:
            ee = ener[:,bands,:]
        elif len(delta_bands) != 0:
            ee = np.zeros((nk,len(delta_bands),ns))
            for idelta, delta in enumerate(delta_bands):
                iband, jband = delta
                ee[:,idelta,:] = ener[:,jband,:]-ener[:,iband,:]
        else:
            ee = ener

        for ispin in range(self.spin.nspin):
            if len(spincolors) == self.spin.nspin:
                kwargs['color'] = spincolors[ispin]
            plt.plot(xaxis, ee[:,:,ispin]+eshift,**kwargs) 

        # Plotting range
        if xmin == None:
            xmin = xaxis.min()
        if xmax == None:
            xmax = xaxis.max()
        if emin == None:
            emin = ee.min()
        if emax == None:
            emax = ee.max()

        # Labelling of the k-point vertices
        if len(vertices) != 0:
            vindex = vertices
        elif hasattr(self,'vertices'):
            vindex = self.vertices
        else:
            vindex = []

        if len(klabels) != 0 and len(vindex) != len(klabels):
            error_msg = "Error in plot_bands: inconsistent number of k-points labels !"
            raise IndexError(error_msg)

        xticks = [] 
        xticks_labels = [] 
        for ilab, klab in enumerate(klabels):
            xticks.append(xaxis[vindex[ilab]])
            xticks_labels.append(klab) 
            plt.plot([xticks]*2,[emin,emax],'-', color='black')
        plt.xticks(xticks, xticks_labels, fontsize=24)

        # Plotting range
        plt.xlim(xmin, xmax)
        plt.ylim(emin, emax)

        # Label and ticks of the y-axis
        if ylabel == None:
            ylabel = 'Energy  (eV)'

        plt.ylabel(ylabel,fontsize=24)
        plt.yticks(fontsize=18)

        ax = plt.gca()  
        yticks = ax.get_yticks()
        yticklabels = []
        for ylab in yticks:
            ytick = ylab*yfactor
            if labelint:
                yticklabels.append(str(int(ytick)))
            else:
                yticklabels.append(str(ytick))
        ax.set_yticklabels(yticklabels)


    def plot_dos(self, npts=500, smear=0.1, kind='gaussian', \
             emin=None, emax=None, ymin=None, ymax=None,
             spincolors=[], eshift=0., labelint=False, \
             ylabel=None, xlabel=None, efactor=1.,\
             delta_bands=[], bands=[], yfactor=1., **kwargs):

        # Plot eigenvalues
        ww = {}
        ee = {}

        if len(bands) != 0:
            for ispin in range(self.spin.nspin):
                wtmp = []   
                etmp = []   
                for ikp in self.eigenval:
                    w = self.wkpts[ikp]
                    for iband in bands:
                        if iband in self.eigenval[ikp]:
                            etmp.append(self.eigenval[ikp][iband][ispin]['E'])
                            wtmp.append(w)
                ww[ispin] = np.array(wtmp)
                ee[ispin] = np.array(etmp)
                    
        elif len(delta_bands) != 0:
            for ispin in range(self.spin.nspin):
                wtmp = []   
                etmp = []   
                for ikp in self.eigenval:
                    w = self.wkpts[ikp]
                    for iband, jband in delta_bands:
                        if iband in self.eigenval[ikp] and  \
                           jband in self.eigenval[ikp]:
                            etmp.append(self.eigenval[ikp][jband][ispin]['E']-\
                                         self.eigenval[ikp][iband][ispin]['E']) 
                            wtmp.append(w)
                ww[ispin] = np.array(wtmp)
                ee[ispin] = np.array(etmp)

        else:
            for ispin in range(self.spin.nspin):
                wtmp = []   
                etmp = []   
                for ikp in self.eigenval:
                    w = self.wkpts[ikp]
                    for iband in self.eigenval[ikp]:
                        etmp.append(self.eigenval[ikp][iband][ispin]['E'])
                        wtmp.append(w)
                ww[ispin] = np.array(wtmp)
                ee[ispin] = np.array(etmp)

        # Energy range
        if emin == None:
            emin = 1.1*np.array([ee[ispin].min() for ispin in range(self.spin.nspin)]).min()
        if emax == None:
            emax = 1.1*np.array([ee[ispin].max() for ispin in range(self.spin.nspin)]).max()
        epts = np.array([emin + ipt*(emax-emin)/npts for ipt in range(npts)])

        # DOS
        dos = {} 
        for ispin in range(self.spin.nspin):
            dos[ispin] = np.zeros(npts)
            for ipt in range(npts):
                if kind == 'lorentz':
                    dos[ispin][ipt] = \
                    np.sum(np.dot((smear/2.)/((epts[ipt]-ee[ispin])**2 + (smear/2.)**2),ww[ispin]))
                else:
                    dos[ispin][ipt] = \
                    np.sum(np.dot(np.exp(-((epts[ipt]-ee[ispin])**2/smear**2)),ww[ispin])) 

        # Plot
        for ispin in range(self.spin.nspin):
            if len(spincolors) == self.spin.nspin:
                kwargs['color'] = spincolors[ispin]
            plt.plot(epts+eshift, dos[ispin], **kwargs)

        # Plotting range
        if ymin == None:
            ymin = 0.
        if ymax == None:
            ymax = 1.1*np.array([dos[ispin].max() for ispin in range(self.spin.nspin)]).max()
        plt.xlim(emin, emax)
        plt.ylim(ymin, ymax)

        # Label and ticks of the y-axis
        if ylabel == None:
            ylabel = 'DOS '

        plt.ylabel(ylabel,fontsize=16)
        plt.yticks(fontsize=12)

        if xlabel == None:
            xlabel = 'Energy  (eV)'

        plt.xlabel(xlabel,fontsize=16)
        plt.xticks(fontsize=12)

        ax = plt.gca()  
        xticks = ax.get_xticks()
        xticklabels = []
        for xlab in xticks:
            xtick = xlab*efactor
            if labelint:
                xticklabels.append(str(int(xtick)))
            else:
                xticklabels.append(str(xtick))
        ax.set_xticklabels(xticklabels)


    def plot_eigenvalues(self, emin=None, emax=None, xmin=None, xmax=None, \
             kshift=0, spincolors=[], eshift=0., xscale=True, \
             klabels=[], vertices=[], labelint=False, ylabel=None, \
             delta_bands=[], bands=[], yfactor=1., **kwargs):

        # K-points coordinates
        nkpts = self.kpts.shape[0]
        if xscale:
            xaxis = [0.]
            for ik in range(1,nkpts):
                d = np.linalg.norm((self.kpts[ik]-self.kpts[ik-1])*self.wkpts[ik])
                xaxis.append(d+xaxis[ik-1])
            xaxis = np.array(xaxis)-xaxis[kshift]
        else:
            xaxis = np.array(range(nkpts))
            xaxis = xaxis - xaxis[kshift]

        # Plot eigenvalues
        xx = {}
        ee = {}

        if len(bands) != 0:
            for ispin in range(self.spin.nspin):
                xtmp = []   
                etmp = []   
                for ikp in self.eigenval:
                    for iband in bands:
                        if iband in self.eigenval[ikp]:
                            etmp.append(self.eigenval[ikp][iband][ispin]['E'])
                            xtmp.append(xaxis[ikp])
                xx[ispin] = np.array(xtmp)
                ee[ispin] = np.array(etmp)
                    
        elif len(delta_bands) != 0:
            for ispin in range(self.spin.nspin):
                xtmp = []   
                etmp = []   
                for ikp in self.eigenval:
                    for iband, jband in delta_bands:
                        if iband in self.eigenval[ikp] and  \
                           jband in self.eigenval[ikp]:
                            etmp.append(self.eigenval[ikp][jband][ispin]['E']-\
                                         self.eigenval[ikp][iband][ispin]['E']) 
                            xtmp.append(xaxis[ikp])
                xx[ispin] = np.array(xtmp)
                ee[ispin] = np.array(etmp)

        else:
            for ispin in range(self.spin.nspin):
                xtmp = []   
                etmp = []   
                for ikp in self.eigenval:
                    for iband in self.eigenval[ikp]:
                        etmp.append(self.eigenval[ikp][iband][ispin]['E'])
                        xtmp.append(xaxis[ikp])
                xx[ispin] = np.array(xtmp)
                ee[ispin] = np.array(etmp)
       

 
        for ispin in range(self.spin.nspin):
            if len(spincolors) == self.spin.nspin:
                kwargs['color'] = spincolors[ispin]
            plt.scatter(xx[ispin], ee[ispin]+eshift, **kwargs)

        # Plotting range
        if xmin == None:
            xmin = xaxis.min()
        if xmax == None:
            xmax = xaxis.max()
        if emin == None:
            emin = np.array([ee[ispin].min() for ispin in range(self.spin.nspin)]).min()
        if emax == None:
            emax = np.array([ee[ispin].max() for ispin in range(self.spin.nspin)]).max()

        # Labelling of the k-point vertices
        if len(vertices) != 0:
            vindex = vertices
        elif hasattr(self,'vertices'):
            vindex = self.vertices
        else:
            vindex = []

        if len(klabels) != 0 and len(vindex) != len(klabels):
            error_msg = "Error in plot_bands: inconsistent number of k-points labels !"
            raise IndexError(error_msg)

        xticks = [] 
        xticks_labels = [] 
        for ilab, klab in enumerate(klabels):
            xticks.append(xaxis[vindex[ilab]])
            xticks_labels.append(klab) 
            plt.plot([xticks]*2,[emin,emax],'-', color='black')
        plt.xticks(xticks, xticks_labels, fontsize=24)

        # Plotting range
        plt.xlim(xmin, xmax)
        plt.ylim(emin, emax)

        # Label and ticks of the y-axis
        if ylabel == None:
            ylabel = 'Energy  (eV)'

        plt.ylabel(ylabel,fontsize=24)
        plt.yticks(fontsize=18)

        ax = plt.gca()  
        yticks = ax.get_yticks()
        yticklabels = []
        for ylab in yticks:
            ytick = ylab*yfactor
            if labelint:
                yticklabels.append(str(int(ytick)))
            else:
                yticklabels.append(str(ytick))
        ax.set_yticklabels(yticklabels)


    def plot_projected_eigenvalues(self, emin=None, emax=None, xmin=None, xmax=None, \
             kshift=0, spincolors=[], eshift=0., xscale=True, colorbar=False, clabel=None,\
             atoms=[], lproj=['s','p'], vmin=None, vmax=None, varsize=False, size=20, \
             klabels=[], vertices=[], labelint=False, ylabel=None, \
             delta_bands=[], bands=[], yfactor=1., **kwargs):

        # K-points coordinates
        nkpts = self.kpts.shape[0]
        if xscale:
            xaxis = [0.]
            for ik in range(1,nkpts):
                d = np.linalg.norm((self.kpts[ik]-self.kpts[ik-1])*self.wkpts[ik])
                xaxis.append(d+xaxis[ik-1])
            xaxis = np.array(xaxis)-xaxis[kshift]
        else:
            xaxis = np.array(range(nkpts))
            xaxis = xaxis - xaxis[kshift]

        # Projections
        projdic = {'s':1,'p':2,'d':3,'f':4}
        iproj = []
        for lp in lproj:
            iproj.append(projdic[lp]) 

        # Plot eigenvalues
        xx = {}
        ee = {}
        pp = {}

        for ispin in range(self.spin.nspin):
            xtmp = []   
            etmp = [] 
            ptmp = []  

            if len(bands) != 0:
                for ikp in self.eigenval:
                    for iband in bands:
                        if iband in self.eigenval[ikp]:
                            if len(atoms) == 0:
                                proj = np.sum(self.eigenval[ikp][iband][ispin]['P'][:,iproj])/\
                                       np.sum(self.eigenval[ikp][iband][ispin]['P'][:,0])
                            else:
                                proj = np.sum(self.eigenval[ikp][iband][ispin]['P'][atoms,iproj])/\
                                       np.sum(self.eigenval[ikp][iband][ispin]['P'][:,0])
                            ptmp.append(proj)
                            etmp.append(self.eigenval[ikp][iband][ispin]['E'])
                            xtmp.append(xaxis[ikp])

            elif len(delta_bands) != 0:
                for ikp in self.eigenval:
                    for iband, jband in delta_bands:
                        if iband in self.eigenval[ikp] and  \
                           jband in self.eigenval[ikp]:
                            if len(atoms) == 0:
                                proj = np.sum(self.eigenval[ikp][iband][ispin]['P'][:,iproj])/\
                                       np.sum(self.eigenval[ikp][iband][ispin]['P'][:,0])
                            else:
                                proj = np.sum(self.eigenval[ikp][iband][ispin]['P'][atoms,iproj])/\
                                       np.sum(self.eigenval[ikp][iband][ispin]['P'][:,0])
                            ptmp.append(proj)
                            etmp.append(self.eigenval[ikp][jband][ispin]['E']-\
                                         self.eigenval[ikp][iband][ispin]['E']) 
                            xtmp.append(xaxis[ikp])

            else:
                for ikp in self.eigenval:
                    for iband in self.eigenval[ikp]:
                
                        if len(atoms) == 0:
                            proj = np.sum(self.eigenval[ikp][iband][ispin]['P'][:,iproj])/\
                                   np.sum(self.eigenval[ikp][iband][ispin]['P'][:,0])
                        else:
                            proj = np.sum(self.eigenval[ikp][iband][ispin]['P'][atoms,iproj])/\
                                   np.sum(self.eigenval[ikp][iband][ispin]['P'][:,0])
                        ptmp.append(proj)
                        etmp.append(self.eigenval[ikp][iband][ispin]['E'])
                        xtmp.append(xaxis[ikp])

            ee[ispin] = np.array(etmp)
            xx[ispin] = np.array(xtmp)
            pp[ispin] = np.array(ptmp)
                    
        if 'vmin' not in kwargs:
            vmin = np.array([pp[ispin].min() for ispin in pp]).min()
            kwargs['vmin'] = vmin
        if 'vmax' not in kwargs:
            vmax = np.array([pp[ispin].max() for ispin in pp]).max()
            kwargs['vmax'] = vmax
        if 'cmap' not in kwargs:
            kwargs['cmap'] = 'jet'

        for ispin in range(self.spin.nspin):

            if varsize:
                kwargs['s'] = (size*(pp[ispin]-vmin)/(vmax-vmin+1e-10))
            else:
                kwargs['s'] = size

            if len(spincolors) == self.spin.nspin:
                kwargs['color'] = spincolors[ispin]
            else:
                kwargs['c'] = pp[ispin]
            sc = plt.scatter(xx[ispin], ee[ispin]+eshift, **kwargs)
            if colorbar:
                if clabel == None:
                    clabel = 'Projection  (%)'
                cb = plt.colorbar(sc)
                cb.ax.tick_params(labelsize=14) 
                cb.set_label(clabel, fontsize=18)
        

        # Plotting range
        if xmin == None:
            xmin = xaxis.min()
        if xmax == None:
            xmax = xaxis.max()
        if emin == None:
            emin = np.array([ee[ispin].min() for ispin in range(self.spin.nspin)]).min()
        if emax == None:
            emax = np.array([ee[ispin].max() for ispin in range(self.spin.nspin)]).max()

        # Labelling of the k-point vertices
        if len(vertices) != 0:
            vindex = vertices
        elif hasattr(self,'vertices'):
            vindex = self.vertices
        else:
            vindex = []

        if len(klabels) != 0 and len(vindex) != len(klabels):
            error_msg = "Error in plot_bands: inconsistent number of k-points labels !"
            raise IndexError(error_msg)

        xticks = [] 
        xticks_labels = [] 
        for ilab, klab in enumerate(klabels):
            xticks.append(xaxis[vindex[ilab]])
            xticks_labels.append(klab) 
            plt.plot([xticks]*2,[emin,emax],'-', color='black')
        plt.xticks(xticks, xticks_labels, fontsize=24)

        # Plotting range
        plt.xlim(xmin, xmax)
        plt.ylim(emin, emax)

        # Label and ticks of the y-axis
        if ylabel == None:
            ylabel = 'Energy  (eV)'

        plt.ylabel(ylabel,fontsize=24)
        plt.yticks(fontsize=18)

        ax = plt.gca()  
        yticks = ax.get_yticks()
        yticklabels = []
        for ylab in yticks:
            ytick = ylab*yfactor
            if labelint:
                yticklabels.append(str(int(ytick)))
            else:
                yticklabels.append(str(ytick))
        ax.set_yticklabels(yticklabels)

